# Phase 7 TODOs
- Fill required fields for listed IDs (id, name, type, owner, tags, path, registry_ref).