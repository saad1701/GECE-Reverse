# Registry Validation Report (Phase 6)

## Coverage Stats
- total_registry_entries: 4
- covered_from_manifest: 0
- orphans_detected: 4
- duplicates_found: 0
- schema_errors: 0
- overall_coverage_percent: 0.0

## Schema Gaps
- none

## Cross-Reference Audit
- missing in registry for manifest added: 0
- orphans in registry (not in manifest): 4
  - sheets data/sheets/Application Based.json
  - sheets data/sheets/Assumptions - Proposal infos.json
  - sheets data/sheets/CoverSheet.json
  - sheets data/sheets/CurrencyUpdate.json

## Normalization Deviations
- none

## Duplicates and Conflicts
- duplicates_found: 0
- owner conflicts: 0