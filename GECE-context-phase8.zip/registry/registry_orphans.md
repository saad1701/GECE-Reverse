# Registry Orphans

- sheets data/sheets/Application Based.json (sheet:Application Based)
- sheets data/sheets/Assumptions - Proposal infos.json (sheet:Assumptions - Proposal infos)
- sheets data/sheets/CoverSheet.json (sheet:CoverSheet)
- sheets data/sheets/CurrencyUpdate.json (sheet:CurrencyUpdate)