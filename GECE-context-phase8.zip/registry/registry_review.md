# Registry Review (Phase 4)

Generated locally from available context.

## Counts (overall)
- added: 29
- removed: 0
- changed: 0
- unchanged: 0

## Unresolved (proposals)
| canonical_id | type | name | path | owner | tags | reason |
| --- | --- | --- | --- | --- | --- | --- |
| sheet:Application Based | sheet | Application Based | data/sheets/Application Based.json | data-team | sheet | derived from id or filename |
| sheet:Assumptions - Proposal infos | sheet | Assumptions - Proposal infos | data/sheets/Assumptions - Proposal infos.json | data-team | sheet | derived from id or filename |
| sheet:CoverSheet | sheet | CoverSheet | data/sheets/CoverSheet.json | data-team | sheet | derived from id or filename |
| sheet:CurrencyUpdate | sheet | CurrencyUpdate | data/sheets/CurrencyUpdate.json | data-team | sheet | derived from id or filename |

## Changed
(none detected with synthesized baseline)

## Orphans
(none detected with synthesized baseline)
