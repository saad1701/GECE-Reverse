#!/usr/bin/env python3
import json, re, pathlib

root = pathlib.Path("data/forms")
forms=[]
for frm in root.glob("*.frm"):
    txt = frm.read_text(encoding="latin-1", errors="ignore")
    m_name = re.search(r'Begin\s+VB\.UserForm\s+(\w+)', txt)
    name = m_name.group(1) if m_name else frm.stem
    def grab(prop):
        m = re.search(rf'^\s*{prop}\s*=\s*(.+)$', txt, re.M)
        return (m.group(1).strip().strip('"')) if m else None
    caption = grab("Caption"); w = grab("Width"); h = grab("Height")
    controls=[]
    for m in re.finditer(r'Begin\s+(\w+)\.(\w+)\s+(\w+)(.*?)End', txt, re.S):
        lib, ctype, cname, body = m.groups()
        def g(prop):
            mm = re.search(rf'^\s*{prop}\s*=\s*(.+)$', body, re.M)
            return (mm.group(1).strip().strip('"')) if mm else None
        controls.append({
            "type": f"{lib}.{ctype}", "name": cname,
            "caption": g("Caption"), "left": g("Left"), "top": g("Top"),
            "width": g("Width"), "height": g("Height"), "tabindex": g("TabIndex")
        })
    forms.append({
        "id": f"form:{name}", "type": "form", "name": name,
        "path": str(frm.as_posix()), "caption": caption,
        "width": w, "height": h, "controls": controls
    })
out={"forms":forms}
pathlib.Path("data/forms/forms_index.json").write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding="utf-8")
print("✓ Parsed", len(forms), "forms to data/forms/forms_index.json")
