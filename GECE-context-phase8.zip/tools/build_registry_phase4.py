#!/usr/bin/env python3
import json, hashlib, pathlib, sys, argparse
from datetime import datetime
ROOT = pathlib.Path(__file__).resolve().parents[1]
def resolve(p, patterns):
    if p and pathlib.Path(p).exists(): return pathlib.Path(p)
    for pat in patterns:
        hits = list(ROOT.glob(pat))
        if hits: return hits[0]
    sys.exit(f"ERROR: missing input. Tried: {patterns}")
ap = argparse.ArgumentParser()
ap.add_argument("--curr",  default=str(ROOT/"manifest_curr.json"))
ap.add_argument("--diff",  default="")
ap.add_argument("--links", default="")
args = ap.parse_args()
curr_p  = resolve(args.curr,  ["manifest_curr.json","**/manifest_curr.json"])
diff_p  = resolve(args.diff,  ["manifest_diff.json","**/manifest_diff.json"])
links_p = resolve(args.links, ["registry_links.json","**/registry_links.json"])
curr  = json.loads(curr_p.read_text(encoding="utf-8"))
diff  = json.loads(diff_p.read_text(encoding="utf-8"))
links = json.loads(links_p.read_text(encoding="utf-8"))
def k(item): return (item.get("type","?"), item.get("name","?"))
existing = {(l.get("type"), l.get("name")) for l in links}
items=[]
for section in ("sheets","vba_modules","forms"):
    for obj in curr.get(section, []):
        items.append({"type":section[:-1],"name":obj.get("name",""),"path":obj.get("path","")})
items_set = {k(i): i for i in items}
unresolved = [items_set[t] for t in items_set if t not in existing]
changed=[]
for section in ("sheets","vba_modules","forms"):
    for obj in diff.get("changed",{}).get(section,[]):
        tup=(section[:-1], obj.get("name",""))
        if tup in existing: changed.append({"type":tup[0],"name":tup[1],"detail":obj})
orphans=[{"type":t,"name":n} for (t,n) in existing if (t,n) not in items_set]
uid=lambda s: hashlib.sha1(s.encode()).hexdigest()[:12]
proposed=[{"action":"ADD_LINK","type":u["type"],"name":u["name"],"path":u.get("path",""),
           "status":"proposed","id":uid(f'{u["type"]}:{u["name"]}:{u.get("path","")}')}
          for u in unresolved]
def tbl(rows, headers):
    out=["|"+"|".join(headers)+"|","|"+"|".join(["---"]*len(headers))+"|"]
    out+=["|"+"|".join(r)+"|" for r in rows]; return "\n".join(out)
review_md=[
f"# Registry Review — Phase 4\nGenerated: {datetime.utcnow().isoformat()}Z\n",
"## Summary\n",
f"- Total in manifest: {len(items)}",
f"- Already linked: {len(existing)}",
f"- Unresolved: {len(unresolved)}",
f"- Changed (linked but modified): {len(changed)}",
f"- Orphans (linked but missing): {len(orphans)}\n",
]
if unresolved:
    review_md+=["## Unresolved (need links)\n",
                tbl([[u["type"],u["name"],u.get("path","")] for u in unresolved],
                    ["Type","Name","Path"]),""]
if changed:
    import json as _j
    review_md+=["## Changed (verify mapping still valid)\n",
                tbl([[c["type"],c["name"],_j.dumps(c["detail"],ensure_ascii=False)[:120]+"…"]
                     for c in changed],["Type","Name","Change Snippet"]),""]
if orphans:
    review_md+=["## Orphans (consider REMOVE)\n",
                tbl([[o["type"],o["name"]] for o in orphans],["Type","Name"]),""]
(ROOT/"registry_review.md").write_text("\n".join(review_md), encoding="utf-8")
(ROOT/"registry_patch.json").write_text(json.dumps(proposed,indent=2,ensure_ascii=False), encoding="utf-8")
print("OK: wrote registry_review.md and registry_patch.json")
