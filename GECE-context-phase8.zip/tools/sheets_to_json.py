#!/usr/bin/env python3
import json, pathlib, sys
from openpyxl import load_workbook

xlsm_path = sys.argv[1]  # path to your .xlsm
out_dir = pathlib.Path("data/sheets"); out_dir.mkdir(parents=True, exist_ok=True)

wb = load_workbook(xlsm_path, data_only=True, keep_vba=True, read_only=True)
items=[]
for ws in wb.worksheets:
    # quick dimensions
    max_row = ws.max_row or 0
    max_col = ws.max_column or 0
    rec = {
        "id": f"sheet:{ws.title}",
        "type": "sheet",
        "name": ws.title,
        "nrows": max_row,
        "ncols": max_col,
        "path": f"data/sheets/{ws.title.replace('/','_')}.json"
    }
    # small sample (first 20x20) to help diffing; avoid heavy dumps
    sample=[]
    for r in ws.iter_rows(min_row=1, max_row=min(20,max_row), min_col=1, max_col=min(20,max_col), values_only=True):
        sample.append(list(r))
    rec["sample20x20"]=sample
    items.append(rec)
    (out_dir / f"{ws.title.replace('/','_')}.json").write_text(json.dumps(rec, indent=2, ensure_ascii=False), encoding="utf-8")

manifest_like={"sheets":items}
(out_dir / "_index.json").write_text(json.dumps(manifest_like, indent=2, ensure_ascii=False), encoding="utf-8")
print(f"✓ Exported {len(items)} sheets to data/sheets/")
